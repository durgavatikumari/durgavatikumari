"""
analysis.py — Sell timing and market analysis engine
No external APIs needed — pure logic based on price data and seasonal patterns.
"""

from datetime import datetime
from data import CROP_DB


def price_forecast(base_modal: int, weeks_ahead: int, peak_months: list, low_months: list) -> int:
    """Estimate future price based on seasonal patterns."""
    current_month = datetime.now().month
    future_month = ((current_month + round(weeks_ahead / 4) - 1) % 12) + 1

    if peak_months and future_month in peak_months:
        return round(base_modal * 1.12)
    if low_months and future_month in low_months:
        return round(base_modal * 0.93)
    return round(base_modal * 1.03)


def sell_verdict(
    crop: str,
    best_modal: int,
    msp,
    weeks_ahead: int,
    trend_rising: int,
    trend_falling: int,
    f30: int,
    f60: int,
    quantity: int,
) -> dict:
    """Compute sell verdict based on price, season, and trends."""
    month = datetime.now().month
    d = CROP_DB[crop]
    peak_months = d.get("peak_months", [])
    low_months = d.get("low_months", [])

    is_peak_now = month in peak_months
    is_low_now = month in low_months
    is_above_msp = (msp is None) or (best_modal >= msp)
    trending_up = trend_rising > trend_falling
    msp_diff = (best_modal - msp) if msp else None

    if weeks_ahead == 0:
        # Sell right now
        if is_peak_now or (is_above_msp and not trending_up):
            label, reason, code = (
                "Sell Now ✅",
                (
                    f"Current month is a seasonal price peak for {crop}. "
                    f"{f'Market price is ₹{msp_diff} above MSP — lock in the premium.' if msp_diff and msp_diff > 0 else ''} "
                    "Prices may soften from here — selling now minimises risk."
                ),
                "sell_now",
            )
        elif trending_up and f30 > best_modal:
            label, reason, code = (
                "Wait 1–2 Weeks ⏳",
                (
                    f"Prices are rising in {trend_rising} mandis. "
                    f"Forecast in 30 days: ₹{f30}/qtl — "
                    f"potential extra earnings of ₹{(f30 - best_modal) * quantity:,}. "
                    "Short wait may be worth it if you can store safely."
                ),
                "wait_2_weeks",
            )
        else:
            label, reason, code = (
                "Sell Now ✅",
                (
                    f"{'Market price is above MSP — good time to sell.' if is_above_msp and msp else ''} "
                    "No strong seasonal signal to wait. Selling now is the lowest-risk option."
                ).strip(),
                "sell_now",
            )

    elif weeks_ahead <= 4:
        if is_low_now and f60 > best_modal:
            label, reason, code = (
                "Hold — Wait for Better Price ⏳",
                (
                    f"Current period is seasonally weak for {crop}. "
                    f"60-day price forecast: ₹{f60}/qtl (+₹{f60 - best_modal}/qtl). "
                    f"Potential extra: ₹{(f60 - best_modal) * quantity:,} if you wait."
                ),
                "wait_1_month",
            )
        else:
            label, reason, code = (
                "Sell in Your Planned Window ✅",
                (
                    f"Prices are {'rising' if trending_up else 'stable'}. "
                    f"{'Above MSP — good return.' if is_above_msp and msp else ''} "
                    "Sell within your planned timeline for reliable returns."
                ).strip(),
                "sell_now",
            )

    elif weeks_ahead <= 10:
        peak_approaching = any(
            0 < ((pm - month + 12) % 12) <= 3
            for pm in peak_months
        )
        if peak_approaching:
            label, reason, code = (
                "Hold — Peak Season Approaching ⏳",
                (
                    f"Price peak season for {crop} is approaching in the next 2–3 months. "
                    f"60-day forecast: ₹{f60}/qtl. "
                    f"Potential gain from waiting: ₹{(f60 - best_modal) * quantity:,}."
                ),
                "wait_1_month",
            )
        else:
            label, reason, code = (
                "Sell as Planned ✅",
                (
                    "No major price improvement expected in your sell window. "
                    "Avoid holding too long — storage cost and quality risk increase over time."
                ),
                "sell_now",
            )

    else:
        label, reason, code = (
            "Reconsider Long Hold ⚠️",
            (
                "Holding 3+ months carries significant risk: storage costs (₹50–100/qtl), "
                "quality deterioration, and market uncertainty. "
                "Best strategy: Sell 60% now and hold 40% for seasonal peak."
            ),
            "hold",
        )

    return {"verdict": code, "verdict_label": label, "verdict_reason": reason}


def get_analysis(crop: str, state: str, quantity: int, timeline_weeks: int) -> dict:
    """Full market analysis — the main /analyse endpoint logic."""
    d = CROP_DB[crop]
    msp = d["msp"]
    mandis = d["mandis"]

    sorted_mandis = sorted(mandis, key=lambda m: m["modal"], reverse=True)
    best = sorted_mandis[0]
    avg_modal = round(sum(m["modal"] for m in mandis) / len(mandis))

    trend_rising = sum(1 for m in mandis if m["trend"] == "rising")
    trend_falling = sum(1 for m in mandis if m["trend"] == "falling")

    f30 = price_forecast(best["modal"], 4, d.get("peak_months", []), d.get("low_months", []))
    f60 = price_forecast(best["modal"], 8, d.get("peak_months", []), d.get("low_months", []))
    f90 = price_forecast(best["modal"], 12, d.get("peak_months", []), d.get("low_months", []))

    verdict = sell_verdict(
        crop, best["modal"], msp, timeline_weeks,
        trend_rising, trend_falling, f30, f60, quantity
    )

    msp_diff = (best["modal"] - msp) if msp else None

    earnings = {
        "at_msp": (msp * quantity) if msp else None,
        "at_best_mandi_today": best["modal"] * quantity,
        "at_avg_mandi_today": avg_modal * quantity,
        "forecast_30_days": f30 * quantity,
        "forecast_60_days": f60 * quantity,
        "extra_vs_msp": (msp_diff * quantity) if msp_diff is not None else None,
    }

    # Find nearest mandi to farmer's state
    home_mandis = [m for m in mandis if state.lower() in m["state"].lower()]
    home_best = sorted(home_mandis, key=lambda m: m["modal"], reverse=True)[0] if home_mandis else None

    return {
        "crop": crop,
        "farmer_state": state,
        "quantity_quintals": quantity,
        "sell_timeline_weeks": timeline_weeks,
        "msp_2024_25": msp,
        "has_msp": msp is not None,
        "season": d["season"],
        "harvest_period": d["harvest"],
        "summary": {
            "best_mandi": best["mandi"],
            "best_state": best["state"],
            "best_modal_price": best["modal"],
            "avg_modal_price": avg_modal,
            "premium_over_msp": msp_diff,
            "mandis_trending_up": trend_rising,
            "mandis_trending_down": trend_falling,
        },
        "verdict": verdict["verdict"],
        "verdict_label": verdict["verdict_label"],
        "verdict_reason": verdict["verdict_reason"],
        "price_forecasts": {
            "current": best["modal"],
            "30_days": f30,
            "60_days": f60,
            "90_days": f90,
            "unit": "₹ per quintal",
        },
        "earnings": earnings,
        "home_state_best_mandi": home_best,
        "mandis": sorted_mandis,
        "market_insight": d.get("insight", ""),
        "data_source": "Agmarknet / APMC 2024-25 seasonal averages",
        "generated_at": datetime.now().isoformat(),
    }
