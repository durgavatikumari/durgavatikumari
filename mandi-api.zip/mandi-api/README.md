# Mandi Market Analyzer API

A free, no-key-required REST API for Indian mandi prices and AI-style
sell-timing analysis. Built with FastAPI. Data sourced from
Agmarknet / APMC records (2024-25 season).

---

## Quick Start (Run on Your Computer)

### Step 1 — Install Python
Download from https://python.org (version 3.10 or newer)

### Step 2 — Install dependencies
Open your terminal / command prompt inside this folder and run:

```bash
pip install -r requirements.txt
```

### Step 3 — Start the API server

```bash
uvicorn main:app --reload --port 8000
```

### Step 4 — Open in browser

- **Interactive docs (try all endpoints):** http://localhost:8000/docs
- **API root:**                             http://localhost:8000/

---

## API Endpoints

| Method | Endpoint              | Description                              |
|--------|-----------------------|------------------------------------------|
| GET    | `/`                   | Welcome page + route list                |
| GET    | `/crops`              | List all 14 supported crops              |
| GET    | `/states`             | List all supported states                |
| GET    | `/price/{crop}`       | Mandi prices for a crop                  |
| GET    | `/msp/{crop}`         | MSP for a crop                           |
| GET    | `/best-mandi/{crop}`  | Single best-priced mandi for a crop      |
| GET    | `/compare`            | Compare prices of multiple crops         |
| GET    | `/analyse`            | Full analysis + sell verdict + earnings  |

---

## Example API Calls

### 1. Get wheat prices across all mandis
```
GET http://localhost:8000/price/Wheat
```

### 2. Get wheat prices in Punjab only
```
GET http://localhost:8000/price/Wheat?state=Punjab
```

### 3. Get MSP for mustard
```
GET http://localhost:8000/msp/Mustard
```

### 4. Full analysis — farmer with 50 quintals of onion in Maharashtra, selling now
```
GET http://localhost:8000/analyse?crop=Onion&state=Maharashtra&quantity=50&timeline=0
```

### 5. Compare wheat, mustard, and chana prices
```
GET http://localhost:8000/compare?crops=Wheat,Mustard,Chana
```

### 6. Best mandi for soybean
```
GET http://localhost:8000/best-mandi/Soybean
```

---

## Response Example — /analyse

```json
{
  "crop": "Wheat",
  "farmer_state": "Punjab",
  "quantity_quintals": 20,
  "sell_timeline_weeks": 0,
  "msp_2024_25": 2275,
  "has_msp": true,
  "season": "Rabi",
  "harvest_period": "Mar–May",
  "summary": {
    "best_mandi": "Khanna",
    "best_state": "Punjab",
    "best_modal_price": 2360,
    "avg_modal_price": 2290,
    "premium_over_msp": 85,
    "mandis_trending_up": 2,
    "mandis_trending_down": 1
  },
  "verdict": "sell_now",
  "verdict_label": "Sell Now ✅",
  "verdict_reason": "Market price is ₹85 above MSP — lock in the premium...",
  "price_forecasts": {
    "current": 2360,
    "30_days": 2391,
    "60_days": 2431,
    "90_days": 2644,
    "unit": "₹ per quintal"
  },
  "earnings": {
    "at_msp": 45500,
    "at_best_mandi_today": 47200,
    "at_avg_mandi_today": 45800,
    "forecast_30_days": 47820,
    "forecast_60_days": 48620,
    "extra_vs_msp": 1700
  },
  "mandis": [...],
  "market_insight": "Punjab and Haryana mandis offer the best wheat prices...",
  "data_source": "Agmarknet / APMC 2024-25 seasonal averages",
  "generated_at": "2025-03-15T10:30:00"
}
```

---

## Deploy Free Online (Share with Anyone)

### Option A — Railway.app (Easiest, Free)
1. Create account at https://railway.app
2. Click "New Project" → "Deploy from GitHub"
3. Upload this folder to GitHub first (github.com → New Repo → upload files)
4. Railway auto-detects Python and deploys
5. You get a public URL like: `https://mandi-api.railway.app`

### Option B — Render.com (Free)
1. Create account at https://render.com
2. New → Web Service → Connect GitHub repo
3. Build command: `pip install -r requirements.txt`
4. Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
5. Free plan gives you a public URL

### Option C — Replit (No GitHub needed)
1. Go to https://replit.com → New Repl → Python
2. Upload all 4 files (main.py, data.py, analysis.py, requirements.txt)
3. Click Run → get a public URL instantly

---

## Connect to Your HTML Agent

Once deployed, update your HTML file to call YOUR API instead of the built-in data.
Replace the `analyse()` function with a fetch call:

```javascript
const response = await fetch(
  'https://your-api-url.railway.app/analyse?crop=Wheat&state=Punjab&quantity=20&timeline=0'
);
const data = await response.json();
// use data.mandis, data.verdict, data.earnings, etc.
```

---

## Supported Crops
Wheat, Rice, Cotton, Soybean, Mustard, Onion, Tomato, Potato,
Groundnut, Maize, Chana, Masoor, Tur, Sugarcane

## Timeline Parameter Values
- `0`  = Right now
- `2`  = 1–2 weeks
- `4`  = 1 month
- `10` = 2–3 months
- `14` = After 3 months

---

## Project Files

```
mandi-api/
├── main.py           ← FastAPI app + all endpoints
├── data.py           ← Agmarknet mandi price database (14 crops)
├── analysis.py       ← Sell timing logic + earnings calculator
├── requirements.txt  ← Python packages needed
└── README.md         ← This file
```

---

Data source: Agmarknet / APMC 2024-25 | Government of India
