"""
Mandi Market Analyzer API
=========================
Built with FastAPI. Serves Agmarknet-based mandi price data
and smart sell-timing analysis for 14 crops across India.

Run locally:
    uvicorn main:app --reload --port 8000

Then open: http://localhost:8000/docs
"""

from fastapi import FastAPI, Query, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from typing import Optional
from datetime import datetime
from data import CROP_DB, ALL_CROPS, ALL_STATES
from analysis import get_analysis

app = FastAPI(
    title="Mandi Market Analyzer API",
    description=(
        "Free API for Indian mandi prices, MSP data, and AI-style "
        "sell-timing analysis. Data sourced from Agmarknet/APMC records (2024-25)."
    ),
    version="1.0.0",
    contact={"name": "Mandi Market Analyzer"},
    license_info={"name": "MIT"},
)

# Allow requests from any frontend (browser, mobile app, website)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET"],
    allow_headers=["*"],
)


# ─── ROOT ────────────────────────────────────────────────────────────────────

@app.get("/", tags=["Info"])
def root():
    """Welcome endpoint — lists all available routes."""
    return {
        "name": "Mandi Market Analyzer API",
        "version": "1.0.0",
        "data_source": "Agmarknet / APMC 2024-25",
        "endpoints": {
            "GET /crops":            "List all supported crops",
            "GET /states":           "List all supported states",
            "GET /price/{crop}":     "Get mandi prices for a crop",
            "GET /msp/{crop}":       "Get MSP for a crop",
            "GET /analyse":          "Full market analysis + sell verdict",
            "GET /compare":          "Compare prices of multiple crops",
            "GET /best-mandi/{crop}":"Get the single best-priced mandi for a crop",
        },
        "docs": "/docs",
        "example": "/analyse?crop=Wheat&state=Punjab&quantity=20&timeline=0",
    }


# ─── CROPS & STATES ──────────────────────────────────────────────────────────

@app.get("/crops", tags=["Reference"])
def list_crops():
    """Return all crops supported by this API."""
    return {
        "count": len(ALL_CROPS),
        "crops": ALL_CROPS,
    }


@app.get("/states", tags=["Reference"])
def list_states():
    """Return all Indian states supported by this API."""
    return {
        "count": len(ALL_STATES),
        "states": ALL_STATES,
    }


# ─── PRICES ──────────────────────────────────────────────────────────────────

@app.get("/price/{crop}", tags=["Prices"])
def get_price(
    crop: str,
    state: Optional[str] = Query(None, description="Filter by state name"),
    sort_by: str = Query("modal", description="Sort by: modal | min | max"),
):
    """
    Get mandi-wise price data for a crop.

    - **crop**: Crop name (e.g. Wheat, Onion, Cotton)
    - **state**: Optional state filter
    - **sort_by**: Sort mandis by modal / min / max price (default: modal)
    """
    crop = crop.strip().title()
    if crop not in CROP_DB:
        raise HTTPException(
            status_code=404,
            detail=f"Crop '{crop}' not found. Use GET /crops for valid options.",
        )

    d = CROP_DB[crop]
    mandis = d["mandis"]

    if state:
        mandis = [m for m in mandis if state.lower() in m["state"].lower()]
        if not mandis:
            raise HTTPException(
                status_code=404,
                detail=f"No mandi data for crop '{crop}' in state '{state}'.",
            )

    sort_key = sort_by if sort_by in ("modal", "min", "max") else "modal"
    mandis = sorted(mandis, key=lambda m: m[sort_key], reverse=True)

    return {
        "crop": crop,
        "season": d["season"],
        "harvest_period": d["harvest"],
        "msp_2024_25": d["msp"],
        "unit": "₹ per quintal",
        "data_source": "Agmarknet / APMC 2024-25",
        "total_mandis": len(mandis),
        "mandis": mandis,
        "generated_at": datetime.now().isoformat(),
    }


# ─── MSP ─────────────────────────────────────────────────────────────────────

@app.get("/msp/{crop}", tags=["Prices"])
def get_msp(crop: str):
    """
    Get the Minimum Support Price (MSP) for a crop (2024-25 season).
    Returns null for crops with no government MSP (e.g. Onion, Tomato).
    """
    crop = crop.strip().title()
    if crop not in CROP_DB:
        raise HTTPException(status_code=404, detail=f"Crop '{crop}' not found.")

    d = CROP_DB[crop]
    return {
        "crop": crop,
        "msp_2024_25": d["msp"],
        "has_msp": d["msp"] is not None,
        "season": d["season"],
        "unit": "₹ per quintal",
        "source": "Government of India MSP notification 2024-25",
    }


# ─── BEST MANDI ──────────────────────────────────────────────────────────────

@app.get("/best-mandi/{crop}", tags=["Prices"])
def get_best_mandi(crop: str):
    """
    Returns the single best-priced mandi (highest modal price) for a crop.
    Useful for quick lookup by mobile apps.
    """
    crop = crop.strip().title()
    if crop not in CROP_DB:
        raise HTTPException(status_code=404, detail=f"Crop '{crop}' not found.")

    d = CROP_DB[crop]
    best = sorted(d["mandis"], key=lambda m: m["modal"], reverse=True)[0]
    msp = d["msp"]

    return {
        "crop": crop,
        "best_mandi": best["mandi"],
        "state": best["state"],
        "modal_price": best["modal"],
        "min_price": best["min"],
        "max_price": best["max"],
        "trend": best["trend"],
        "msp": msp,
        "premium_over_msp": (best["modal"] - msp) if msp else None,
        "unit": "₹ per quintal",
    }


# ─── COMPARE ─────────────────────────────────────────────────────────────────

@app.get("/compare", tags=["Analysis"])
def compare_crops(
    crops: str = Query(..., description="Comma-separated crop names, e.g. Wheat,Mustard,Chana"),
):
    """
    Compare best mandi prices across multiple crops side by side.
    Useful for farmers deciding which crop to sell first.
    """
    crop_list = [c.strip().title() for c in crops.split(",")]
    results = []
    not_found = []

    for crop in crop_list:
        if crop not in CROP_DB:
            not_found.append(crop)
            continue
        d = CROP_DB[crop]
        best = sorted(d["mandis"], key=lambda m: m["modal"], reverse=True)[0]
        msp = d["msp"]
        results.append({
            "crop": crop,
            "best_mandi": best["mandi"],
            "state": best["state"],
            "modal_price": best["modal"],
            "msp": msp,
            "premium_over_msp": (best["modal"] - msp) if msp else None,
            "trend": best["trend"],
            "season": d["season"],
        })

    results = sorted(results, key=lambda r: r["modal_price"], reverse=True)

    return {
        "comparison": results,
        "best_crop_to_sell": results[0]["crop"] if results else None,
        "not_found": not_found,
        "unit": "₹ per quintal",
    }


# ─── FULL ANALYSIS ───────────────────────────────────────────────────────────

@app.get("/analyse", tags=["Analysis"])
def analyse(
    crop: str = Query(..., description="Crop name (e.g. Wheat)"),
    state: str = Query(..., description="Farmer's state (e.g. Punjab)"),
    quantity: int = Query(20, ge=1, le=999999, description="Quantity in quintals"),
    timeline: int = Query(0, description="Weeks before selling: 0=now, 2=2wks, 4=1mo, 10=2-3mo, 14=3mo+"),
):
    """
    Full market analysis for a farmer.

    Returns:
    - Mandi price table (all mandis, sorted best to worst)
    - Sell verdict (sell_now / wait_2_weeks / wait_1_month / hold)
    - Earnings comparison (MSP vs best mandi vs forecast)
    - Market insight text
    - Price forecasts for 30 and 60 days
    """
    crop = crop.strip().title()
    if crop not in CROP_DB:
        raise HTTPException(
            status_code=404,
            detail=f"Crop '{crop}' not found. Use GET /crops for valid options.",
        )

    result = get_analysis(crop, state, quantity, timeline)
    return result
